// analyze.c

float findMax (float a1, float a2, float a3, float a4)
{

}

float computeAverage (float* start, float* end)
{

}

main()
{

  return 0;
}