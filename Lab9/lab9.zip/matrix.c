// matrix.c

// compute product and the transpose of product.

# include <stdio.h>

main(void)
{
  int A[3][4] = { 1, 2,  3,  1,
	              0, 1, -5,  2,
				  6, 2,  0, -2} ;
	               
  int B[4][3] = { 1,  0, -1,
	              0,  1,  1,
				  2,  3,  4,
				  0, -1,  0} ;


  



  return 0;
}
