// image.c

# include <stdio.h>

float computeThreshold (int  image[8][8])
{

}

void convertToBinaryImage (int image[8][8], float threshold)
{
  
}

main()
{
   int letter[8][8] =
   {
     6, 6, 6, 6, 6, 6, 6, 6,
     6, 2, 2, 2, 2, 2, 2, 6,
     6, 3, 1, 0, 1, 1, 2, 7,
     6, 6, 5, 0, 1, 5, 6, 6,
     6, 6, 5, 3, 3, 5, 6, 7,
     7, 6, 5, 3, 2, 6, 6, 7,
     7, 6, 6, 2, 2, 5, 6, 7,
     7, 7, 7, 7, 7, 7, 7, 7
   };

 

  return 0;
}



