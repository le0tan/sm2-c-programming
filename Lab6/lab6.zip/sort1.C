﻿// Lab 6. Sorting Algorithm

# include <stdio.h>
# include <stdlib.h>

# define n 65300
# define seed 29

int a[n];

main ()
{
  int i;
  long checksum;
  int sorted;

  srand(seed);  // fix the seed
  for(i=0;i<n;i++) a[i]= rand();

  checksum = 0;
  for(i = 0; i <n; i++ ){ checksum +=a[i];}
  printf("\nChecksum before sorting: %ld\n", checksum);

  


  // Program the algorithm (without variation) written in the handout

    

  checksum = 0;
  for(i = 0; i <n; i++ ){checksum +=a[i];}
  printf("\nChecksum after sorting: %ld \n", checksum);

  sorted = 1;
  for(i = 0; i < n-1; i++ )
  {
    if (a[i] > a[i+1])
    {
       sorted = 0;
       break;
    }
  }

  if (sorted ==1)
     printf ("\n====> Sorted! \n");
  else
     printf ("====> Not sorted \n");

  return 0;
}